wget https://www.dropbox.com/s/ghtmzeuim92ub4g/datasets.zip
unzip datasets.zip